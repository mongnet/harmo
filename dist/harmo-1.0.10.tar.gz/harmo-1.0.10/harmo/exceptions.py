#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time : 2023-9-17 13:42
# @Author : hubiao
# @Email : 250021520@qq.com
# @File : exceptions.py

class ParserError(Exception):
    pass

class ExtractExpressionError(Exception):
    pass
