#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time : 2022-12-4 17:28
# @Author : hubiao
# @Email : 250021520@qq.com
# @File : config.py

class Config:
    project_root_dir = ""
