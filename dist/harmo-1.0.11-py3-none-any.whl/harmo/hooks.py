#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time : 2023-6-10 23:30
# @Author : hubiao
# @Email : 250021520@qq.com
# @File : hooks.py

def pytest_harmo_title(report):
    """Called before adding the title to the report"""