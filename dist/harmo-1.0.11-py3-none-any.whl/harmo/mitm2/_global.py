import json

GLOBAL ={}